" Copyright (c) 2023 Ivan Bityutskiy 
" 
" Permission to use, copy, modify, and distribute this software for any
" purpose with or without fee is hereby granted, provided that the above
" copyright notice and this permission notice appear in all copies.
" 
" THE SOFTWARE IS PROVIDED 'AS IS' AND THE AUTHOR DISCLAIMS ALL WARRANTIES
" WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
" MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
" ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
" WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
" ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
" OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"
" Type: vim plugin
" Name: kament
" Description: comments/uncomments strings, does not work with tab characters used as indentation.

" checks <...>kament/ftplugin directory for existence of detected filetypes *.vim, returns 1 on success.
function! g:kament#FtFileExists() abort
  if exists('g:kament#slkament')
    return 1
  endif
  echom "Err: no file defines comments for filetype " . &filetype . ", add one in <...>pack/plugins/start/kament/ftplugin."
  return 0
endfunction

" determine the minimum indent for multiple lines.
function! g:kament#CheckMinIndent(start, end) abort
  let l:min_indent = -1
  let l:indent = a:start
  while l:indent <= a:end
    if l:min_indent == -1 || indent(l:indent) < l:min_indent
      let l:min_indent = indent(l:indent)
    endif
    let l:indent += 1
  endwhile
  return l:min_indent
endfunction

function! g:kament#ProcessLines(lnum, line, indent, add_comment) abort
  " if there is no indent.
  let l:prefix = a:indent > 0 ? a:line[:a:indent - 1] : ''
  if a:add_comment
    call setline(a:lnum, l:prefix . g:kament#slkament . a:line[a:indent:])
  else
    call setline(a:lnum, l:prefix . a:line[a:indent + len(g:kament#slkament):])
  endif
endfunction


" toggle comments on selected line(s).
function! g:kament#Ctoggle(count) abort
  if !g:kament#FtFileExists()
    return
  endif
  let l:start = line('.')
  let l:end = l:start + a:count - 1
  if l:end > line('$') " $ == EOF
    let l:end = line('$')
  endif
  let l:indent = g:kament#CheckMinIndent(l:start, l:end)
  let l:lines = getline(l:start, l:end)
  let l:cur_row = getcurpos()[1]
  let l:cur_col = getcurpos()[2]
  let l:lnum = l:start
  if l:lines[0][l:indent:l:indent + len(g:kament#slkament) - 1] ==# g:kament#slkament
    let l:add_comment = 0
    let l:cur_offset = -len(g:kament#slkament)
  else
    let l:add_comment = 1
    let l:cur_offset = len(g:kament#slkament)
  endif
  for l:line in l:lines
    call g:kament#ProcessLines(l:lnum, l:line, l:indent, l:add_comment)
    let l:lnum += 1
  endfor
  call cursor(l:cur_row, l:cur_col + l:cur_offset)
endfunction

