" Copyright (c) 2023 Ivan Bityutskiy 
" 
" Permission to use, copy, modify, and distribute this software for any
" purpose with or without fee is hereby granted, provided that the above
" copyright notice and this permission notice appear in all copies.
" 
" THE SOFTWARE IS PROVIDED 'AS IS' AND THE AUTHOR DISCLAIMS ALL WARRANTIES
" WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
" MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
" ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
" WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
" ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
" OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"
" Type: vim plugin
" Name: pshighlight
" Description: filetype detection for PowerShell files.

" only do this when not done yet for this buffer
if exists("b:did_ftplugin") | finish | endif

" don't load another plug-in for this buffer
let b:did_ftplugin = 1

setlocal tw=0
setlocal commentstring=#%s
setlocal formatoptions=tcqro
" enable autocompletion of hyphenated PowerShell commands,
" e.g. Get-Content or Get-ADUser
setlocal iskeyword+=-

" change the browse dialog on Win32 to show mainly PowerShell-related files
if has("gui_win32")
  let b:browsefilter =
    \ "All PowerShell Files (*.ps1, *.psd1, *.psm1, *.ps1xml)\t*.ps1;*.psd1;*.psm1;*.ps1xml\n" .
    \ "PowerShell Script Files (*.ps1)\t*.ps1\n" .
    \ "PowerShell Module Files (*.psd1, *.psm1)\t*.psd1;*.psm1\n" .
    \ "PowerShell XML Files (*.ps1xml)\t*.ps1xml\n" .
    \ "All Files (*.*)\t*.*\n"
endif

" undo the stuff we changed
let b:undo_ftplugin = "setlocal tw< cms< fo<" .
  \ " | unlet! b:browsefilter"

