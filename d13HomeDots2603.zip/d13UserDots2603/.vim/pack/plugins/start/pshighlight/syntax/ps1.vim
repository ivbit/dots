" Copyright (c) 2023 Ivan Bityutskiy 
" 
" Permission to use, copy, modify, and distribute this software for any
" purpose with or without fee is hereby granted, provided that the above
" copyright notice and this permission notice appear in all copies.
" 
" THE SOFTWARE IS PROVIDED 'AS IS' AND THE AUTHOR DISCLAIMS ALL WARRANTIES
" WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
" MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
" ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
" WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
" ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
" OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"
" Type: vim plugin
" Name: pshighlight
" Description: syntax highlighting for PowerShell files.

" the following settings are available for tuning syntax highlighting:
" let ps1_nofold_blocks = 1
" let ps1_nofold_sig = 1
" let ps1_nofold_region = 1

" compatible VIM syntax file start
if version < 600
  syntax clear
elseif exists("b:current_syntax")
  finish
endif

" operators contain dashes
setlocal iskeyword+=-

" powerShell doesn't care about case
syntax case ignore

" sync-ing method
syntax sync minlines=100

" certain tokens can't appear at the top level of the document
syntax cluster ps1NotTop contains=@ps1Comment,ps1CDocParam,ps1FunctionDeclaration

" comments and special comment words
syntax keyword ps1CommentTodo TODO FIXME XXX TBD HACK NOTE contained
syntax match ps1CDocParam /.*/ contained
syntax match ps1CommentDoc /^\s*\zs\.\w\+\>/ nextgroup=ps1CDocParam contained
syntax match ps1CommentDoc /#\s*\zs\.\w\+\>/ nextgroup=ps1CDocParam contained
syntax match ps1Comment /#.*/ contains=ps1CommentTodo,ps1CommentDoc,@Spell
syntax region ps1Comment start="<#" end="#>" contains=ps1CommentTodo,ps1CommentDoc,@Spell

" language keywords and elements
syntax keyword ps1Conditional if else elseif switch default
syntax keyword ps1Repeat while for do until break continue foreach in
syntax match ps1Repeat /\<foreach\>/ nextgroup=ps1Block skipwhite
syntax match ps1Keyword /\<while\>/ nextgroup=ps1Block skipwhite
syntax match ps1Keyword /\<where\>/ nextgroup=ps1Block skipwhite

syntax keyword ps1Exception begin process end exit inlinescript parallel sequence
syntax keyword ps1Keyword try catch finally throw
syntax keyword ps1Keyword return filter in trap param data dynamicparam 
syntax keyword ps1Constant $true $false $null
syntax match ps1Constant +\$?+
syntax match ps1Constant +\$_+
syntax match ps1Constant +\$\$+
syntax match ps1Constant +\$^+

" keywords reserved for future use
syntax keyword ps1Keyword class define from using var

" function declarations
syntax keyword ps1Keyword function nextgroup=ps1Function skipwhite
syntax keyword ps1Keyword filter nextgroup=ps1Function skipwhite
syntax keyword ps1Keyword workflow nextgroup=ps1Function skipwhite
syntax keyword ps1Keyword configuration nextgroup=ps1Function skipwhite
syntax keyword ps1Keyword class nextgroup=ps1Function skipwhite
syntax keyword ps1Keyword enum nextgroup=ps1Function skipwhite

" function declarations and invocations
syntax match ps1Cmdlet /\v(add|clear|close|copy|enter|exit|find|format|get|hide|join|lock|move|new|open|optimize|pop|push|redo|remove|rename|reset|search|select|Set|show|skip|split|step|switch|undo|unlock|watch)(-\w+)+/ contained
syntax match ps1Cmdlet /\v(connect|disconnect|read|receive|send|write)(-\w+)+/ contained
syntax match ps1Cmdlet /\v(backup|checkpoint|compare|compress|convert|convertfrom|convertto|dismount|edit|expand|export|group|import|initialize|limit|merge|mount|out|publish|restore|save|sync|unpublish|update)(-\w+)+/ contained
syntax match ps1Cmdlet /\v(debug|measure|ping|repair|resolve|test|trace)(-\w+)+/ contained
syntax match ps1Cmdlet /\v(approve|assert|build|complete|confirm|deny|deploy|disable|enable|install|invoke|register|request|restart|resume|start|stop|submit|suspend|uninstall|unregister|wait)(-\w+)+/ contained
syntax match ps1Cmdlet /\v(block|grant|protect|revoke|unblock|unprotect)(-\w+)+/ contained
syntax match ps1Cmdlet /\v(use)(-\w+)+/ contained

" other functions
syntax match ps1Function /\w\+\(-\w\+\)\+/ contains=ps1Cmdlet

" type declarations
syntax match ps1Type /\[[a-z_][a-z0-9_.,\[\]]\+\]/

" variable references
syntax match ps1ScopeModifier /\(global:\|local:\|private:\|script:\)/ contained
syntax match ps1Variable /\$\w\+\(:\w\+\)\?/ contains=ps1ScopeModifier
syntax match ps1Variable /\${\w\+\(:\w\+\)\?}/ contains=ps1ScopeModifier

" operators
syntax keyword ps1Operator -eq -ne -ge -gt -lt -le -like -notlike -match -notmatch -replace -split -contains -notcontains
syntax keyword ps1Operator -ieq -ine -ige -igt -ile -ilt -ilike -inotlike -imatch -inotmatch -ireplace -isplit -icontains -inotcontains
syntax keyword ps1Operator -ceq -cne -cge -cgt -clt -cle -clike -cnotlike -cmatch -cnotmatch -creplace -csplit -ccontains -cnotcontains
syntax keyword ps1Operator -in -notin
syntax keyword ps1Operator -is -isnot -as -join
syntax keyword ps1Operator -and -or -not -xor -band -bor -bnot -bxor
syntax keyword ps1Operator -f
syntax match ps1Operator /!/
syntax match ps1Operator /=/
syntax match ps1Operator /+=/
syntax match ps1Operator /-=/
syntax match ps1Operator /\*=/
syntax match ps1Operator /\/=/
syntax match ps1Operator /%=/
syntax match ps1Operator /+/
syntax match ps1Operator /-\(\s\|\d\|\.\|\$\|(\)\@=/
syntax match ps1Operator /\*/
syntax match ps1Operator /\//
syntax match ps1Operator /|/
syntax match ps1Operator /%/
syntax match ps1Operator /&/
syntax match ps1Operator /::/
syntax match ps1Operator /,/
syntax match ps1Operator /\(^\|\s\)\@<=\. \@=/

" regular Strings
" these aren't precisely correct and could use some work
syntax region ps1String start=/"/ skip=/`"/ end=/"/ contains=@ps1StringSpecial,@Spell
syntax region ps1String start=/'/ skip=/''/ end=/'/

" here-strings
syntax region ps1String start=/@"$/ end=/^"@/ contains=@ps1StringSpecial,@Spell
syntax region ps1String start=/@'$/ end=/^'@/

" interpolation
syntax match ps1Escape /`./
syntax region ps1Interpolation matchgroup=ps1InterpolationDelimiter start="$(" end=")" contained contains=ALLBUT,@ps1NotTop
syntax region ps1NestedParentheses start="(" skip="\\\\\|\\)" matchgroup=ps1Interpolation end=")" transparent contained
syntax cluster ps1StringSpecial contains=ps1Escape,ps1Interpolation,ps1Variable,ps1Boolean,ps1Constant,ps1BuiltIn,@Spell

" numbers
syntax match ps1Number "\(\<\|-\)\@<=\(0[xX]\x\+\|\d\+\)\([KMGTP][B]\)\=\(\>\|-\)\@="
syntax match ps1Number "\(\(\<\|-\)\@<=\d\+\.\d*\|\.\d\+\)\([eE][-+]\=\d\+\)\=[dD]\="
syntax match ps1Number "\<\d\+[eE][-+]\=\d\+[dD]\=\>"
syntax match ps1Number "\<\d\+\([eE][-+]\=\d\+\)\=[dD]\>"

" constants
syntax match ps1Boolean "$\%(true\|false\)\>"
syntax match ps1Constant /\$null\>/
syntax match ps1BuiltIn "$^\|$?\|$_\|$\$"
syntax match ps1BuiltIn "$\%(args\|error\|foreach\|home\|input\)\>"
syntax match ps1BuiltIn "$\%(match\(es\)\?\|myinvocation\|host\|lastexitcode\)\>"
syntax match ps1BuiltIn "$\%(ofs\|shellid\|stacktrace\)\>"

" folding blocks
if !exists('g:ps1_nofold_blocks')
  syntax region ps1Block start=/{/ end=/}/ transparent fold
endif

if !exists('g:ps1_nofold_region')
  syntax region ps1Region start=/#region/ end=/#endregion/ transparent fold keepend extend
endif

if !exists('g:ps1_nofold_sig')
  syntax region ps1Signature start=/# SIG # Begin signature block/ end=/# SIG # End signature block/ transparent fold
endif

" setup default color highlighting
if version >= 508 || !exists("did_ps1_syn_inits")
  if version < 508
    let did_ps1_syn_inits = 1
    command -nargs=+ HiLink highlight link <args>
  else
    command -nargs=+ HiLink highlight def link <args>
  endif

  HiLink ps1Number Number
  HiLink ps1Block Block
  HiLink ps1Region Region
  HiLink ps1Exception Exception
  HiLink ps1Constant Constant
  HiLink ps1String String
  HiLink ps1Escape SpecialChar
  HiLink ps1InterpolationDelimiter Delimiter
  HiLink ps1Conditional Conditional
  HiLink ps1Cmdlet Function
  HiLink ps1Function Identifier
  HiLink ps1Variable Identifier
  HiLink ps1Boolean Boolean
  HiLink ps1Constant Constant
  HiLink ps1BuiltIn StorageClass
  HiLink ps1Type Type
  HiLink ps1ScopeModifier StorageClass
  HiLink ps1Comment Comment
  HiLink ps1CommentTodo Todo
  HiLink ps1CommentDoc Tag
  HiLink ps1CDocParam Identifier
  HiLink ps1Operator Operator
  HiLink ps1Repeat Repeat
  HiLink ps1RepeatAndCmdlet Repeat
  HiLink ps1Keyword Keyword
  HiLink ps1KeywordAndCmdlet Keyword
  delcommand HiLink
endif

let b:current_syntax = "ps1"

