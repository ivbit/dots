" Copyright (c) 2023 Ivan Bityutskiy 
" 
" Permission to use, copy, modify, and distribute this software for any
" purpose with or without fee is hereby granted, provided that the above
" copyright notice and this permission notice appear in all copies.
" 
" THE SOFTWARE IS PROVIDED 'AS IS' AND THE AUTHOR DISCLAIMS ALL WARRANTIES
" WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
" MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
" ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
" WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
" ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
" OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"
" Type: vim plugin
" Name: pshighlight
" Description: syntax highlighting for PowerShell files.

" compatible VIM syntax file start
if version < 600
  syntax clear
elseif exists("b:current_syntax")
  finish
endif

let s:ps1xml_cpo_save = &cpo
set cpo&vim

doautocmd syntax xml
unlet b:current_syntax

syntax case ignore
syntax include @ps1xmlScriptBlock <sfile>:p:h/ps1.vim
unlet b:current_syntax

syntax region ps1xmlScriptBlock
  \ matchgroup=xmlTag start="<Script>"
  \ matchgroup=xmlEndTag end="</Script>"
  \ fold
  \ contains=@ps1xmlScriptBlock
  \ keepend
syntax region ps1xmlScriptBlock
  \ matchgroup=xmlTag start="<ScriptBlock>"
  \ matchgroup=xmlEndTag end="</ScriptBlock>"
  \ fold
  \ contains=@ps1xmlScriptBlock
  \ keepend
syntax region ps1xmlScriptBlock
  \ matchgroup=xmlTag start="<GetScriptBlock>"
  \ matchgroup=xmlEndTag end="</GetScriptBlock>"
  \ fold
  \ contains=@ps1xmlScriptBlock
  \ keepend
syntax region ps1xmlScriptBlock
  \ matchgroup=xmlTag start="<SetScriptBlock>"
  \ matchgroup=xmlEndTag end="</SetScriptBlock>"
  \ fold
  \ contains=@ps1xmlScriptBlock
  \ keepend

syntax cluster xmlRegionHook add=ps1xmlScriptBlock

let b:current_syntax = "ps1xml"

let &cpo = s:ps1xml_cpo_save
unlet s:ps1xml_cpo_save

