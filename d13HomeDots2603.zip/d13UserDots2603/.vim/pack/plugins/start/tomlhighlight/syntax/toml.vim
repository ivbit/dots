" Copyright (c) 2023 Ivan Bityutskiy 
" 
" Permission to use, copy, modify, and distribute this software for any
" purpose with or without fee is hereby granted, provided that the above
" copyright notice and this permission notice appear in all copies.
" 
" THE SOFTWARE IS PROVIDED 'AS IS' AND THE AUTHOR DISCLAIMS ALL WARRANTIES
" WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
" MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
" ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
" WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
" ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
" OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"
" Type: vim plugin
" Name: toml
" Description: syntax highlighting for Toml files.

if exists('b:current_syntax')
  finish
endif

syntax match tomlEscape /\\[btnfr"/\\]/ display contained
syntax match tomlEscape /\\u\x\{4}/ contained
syntax match tomlEscape /\\U\x\{8}/ contained
syntax match tomlLineEscape /\\$/ contained

" basic strings
syntax region tomlString oneline start=/"/ skip=/\\\\\|\\"/ end=/"/ contains=tomlEscape
" multi-line basic strings
syntax region tomlString start=/"""/ end=/"""/ contains=tomlEscape,tomlLineEscape
" literal strings
syntax region tomlString oneline start=/'/ end=/'/
" multi-line literal strings
syntax region tomlString start=/'''/ end=/'''/

syntax match tomlInteger /[+-]\=\<[1-9]\(_\=\d\)*\>/ display
syntax match tomlInteger /[+-]\=\<0\>/ display
syntax match tomlInteger /[+-]\=\<0x[[:xdigit:]]\(_\=[[:xdigit:]]\)*\>/ display
syntax match tomlInteger /[+-]\=\<0o[0-7]\(_\=[0-7]\)*\>/ display
syntax match tomlInteger /[+-]\=\<0b[01]\(_\=[01]\)*\>/ display
syntax match tomlInteger /[+-]\=\<\(inf\|nan\)\>/ display

syntax match tomlFloat /[+-]\=\<\d\(_\=\d\)*\.\d\+\>/ display
syntax match tomlFloat /[+-]\=\<\d\(_\=\d\)*\(\.\d\(_\=\d\)*\)\=[eE][+-]\=\d\(_\=\d\)*\>/ display

syntax match tomlBoolean /\<\%(true\|false\)\>/ display

" the Date and Time on the Internet: Timestamps: https://tools.ietf.org/html/rfc3339
syntax match tomlDate /\d\{4\}-\d\{2\}-\d\{2\}/ display
syntax match tomlDate /\d\{2\}:\d\{2\}:\d\{2\}\%(\.\d\+\)\?/ display
syntax match tomlDate /\d\{4\}-\d\{2\}-\d\{2\}[T ]\d\{2\}:\d\{2\}:\d\{2\}\%(\.\d\+\)\?\%(Z\|[+-]\d\{2\}:\d\{2\}\)\?/ display

syntax match tomlDotInKey /\v[^.]+\zs\./ contained display
syntax match tomlKey /\v(^|[{,])\s*\zs[[:alnum:]._-]+\ze\s*\=/ contains=tomlDotInKey display
syntax region tomlKeyDq oneline start=/\v(^|[{,])\s*\zs"/ end=/"\ze\s*=/ contains=tomlEscape
syntax region tomlKeySq oneline start=/\v(^|[{,])\s*\zs'/ end=/'\ze\s*=/

syntax region tomlTable oneline start=/^\s*\[[^\[]/ end=/\]/ contains=tomlKey,tomlKeyDq,tomlKeySq,tomlDotInKey

syntax region tomlTableArray oneline start=/^\s*\[\[/ end=/\]\]/ contains=tomlKey,tomlKeyDq,tomlKeySq,tomlDotInKey

syntax region tomlKeyValueArray start=/=\s*\[\zs/ end=/\]/ contains=@tomlValue

syntax region tomlArray start=/\[/ end=/\]/ contains=@tomlValue contained

syntax cluster tomlValue contains=tomlArray,tomlString,tomlInteger,tomlFloat,tomlBoolean,tomlDate,tomlComment

syntax keyword tomlTodo TODO FIXME XXX BUG contained

syntax match tomlComment /#.*/ contains=@Spell,tomlTodo

highlight def link tomlComment Comment
highlight def link tomlTodo Todo
highlight def link tomlTableArray Title
highlight def link tomlTable Title
highlight def link tomlDotInKey Normal
highlight def link tomlKeySq Identifier
highlight def link tomlKeyDq Identifier
highlight def link tomlKey Identifier
highlight def link tomlDate Constant
highlight def link tomlBoolean Boolean
highlight def link tomlFloat Float
highlight def link tomlInteger Number
highlight def link tomlString String
highlight def link tomlLineEscape SpecialChar
highlight def link tomlEscape SpecialChar

syntax sync minlines=500
let b:current_syntax = 'toml'

