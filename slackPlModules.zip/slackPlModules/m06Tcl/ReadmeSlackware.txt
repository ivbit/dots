

Makefile.PL is made for Debian/Ubuntu, to install on Slackware you need to
manually specify the path to tclConfig.sh to install Tcl (Tcl.pm):
perl Makefile.PL --tclconfig /usr/lib64/tclConfig.sh
make
make test
make install
Then simply install Tkx (Tkx.pm) from Tkx directory:
perl Makefile.PL
make
make test
make install


